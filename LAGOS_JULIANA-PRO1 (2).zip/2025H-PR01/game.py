import pygame
import random
from config import *
from menus import main_menu, select_difficulty, pause_menu, draw_text, draw_center_line

# Initialiser pygame
pygame.init()

# Initialiser la fenêtre du jeu
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))

# Contrôle de la fréquence d'images
clock = pygame.time.Clock()

# Police pour aficher du texte
font = pygame.font.Font(None, 36)

def reset_ball(ball_x, ball_y, ball_velocity_x, ball_velocity_y):
    """ 
    Fonction pour réinitialiser la balle lorsqu'un joueur gagne un point
    """
    #redeffinir la position de la balle pour quelle soit centree en x et aléatoire en y
    
    
    # TODO : RÉINITIALISER LA POSITION DE LA BALLE AU CENTRE DU JEU
    # Ici, vous devez redéfinir la position de la balle pour qu'elle soit au centre de la fenêtre du jeu en x (c'est-à-dire, sur la ligne pointillée)
    ball_x=SCREEN_WIDTH//2
    ball_y=random.randint(0,SCREEN_HEIGHT)
    #randint prend entier
    #choice direction aléatoire

    # TODO : LANCEMENT DE LA BALLE APRÈS RÉINITIALISATION
    # Si le joueur 2 a gagné un point, relancer la balle de son côté (à la droite) avec une position aléatoire en y (par en haut ou par en bas), à partir de la ligne pointillée
    # Si le joueur 1 a gagné un point, relancer la balle de son côté (à la gauche) avec une position aléatoire en y (par en haut ou par en bas), à partir de la ligne pointillée
    if player2_score==player2_score+1:
        ball_velocity_x=BALL_SPEED_X
        ball_velocity_y=random.choice([-BALL_SPEED_Y,BALL_SPEED_Y])
    if player1_score==player1_score+1:
        ball_velocity_x=-BALL_SPEED_X
        ball_velocity_y=random.choice([-BALL_SPEED_Y,BALL_SPEED_Y])
    return ball_x, ball_y, ball_velocity_x, ball_velocity_y

def play_game(player1_y, player2_y, player1_score, player2_score, ball_x, ball_y, ball_velocity_x, ball_velocity_y):
    """
    Fonction qui lance et gère le jeu 
    """
    # Définition de la variable "game_mode" comme étant la sortie du menu principal (soit "single player" ou "multi player")
    game_mode = main_menu()

    # Définition de la variable "difficulty" comme étant la sortie du menu "select difficulty" (soit "easy", "medium", ou "hard")
    if game_mode == 'single player':
        difficulty = select_difficulty() 
    else :
        difficulty = None

    running = True
    while running:
        screen.fill(BLACK)

        # Gestion des touches de clavier 
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    # Show the pause menu and capture the return value
                    result = pause_menu()
                    if result == "main menu":
                        reset_game()  # Reset game and return to main menu
                        return  # Exit the play_game loop
                    # If 'resume', simply break out of the pause logic
                    elif result == 'resume':
                        break  # Continue the main game loop

        # Contrôle des touches de clavier
        keys = pygame.key.get_pressed()

        # TODO : IMPLÉMENTATION DU MOUVEMENT DES RAQUETTES POUR L'OPTION "MULTI PLAYER"
        #
        # Ici, vous devez implémenter le mouvement des raquettes des joueurs 1 et 2 pour le cas "multi player"
        #
        # Le mouvement de la raquette du joueur 1 doit être contrôlé par les touches "w" et "s" du clavier pour les déplacements de haut en bas, respectivement. 
        # Le mouvement de la raquette du joueur 2 doit être contrôlé par les flèches en haut et en bas du clavier. 
        #
        # * Note 1 : Pour la gestion des touches de clavier, utilisez les fonctions du module key de la librairie pygame.
        #
        # * Note 2 : Vous devez utiliser la variable "paddle_speed" pour gérer les déplacements des raquettes. 
        #
        # * Note 3 : Lorsque les raquettes atteignent le haut ou le bas de la fenêtre de jeu, elles ne doivent pas dépasser ces limites. 
        #          Assurez-vous que leur position reste dans les bornes définies par la hauteur de l'écran.
    #question: faut il utiliser getpressed (touche continuellement) ou  .keydown (touche une fois)
    #reminder: player1_y = paddle1y
    #reminder: point dorigine sur pygame est en haut a gauche (donc qd on monte, on diminue la valeur de y)et (qd on descend, on augmente la valeur de y)
        if game_mode == 'multi player':
            #paddle_speed = 11
            if keys[pygame.K_w] and player1_y > 0:
                player1_y -= paddle_speed #player1_y = player1_y - paddle_speed
                #qd tu presse sur w, la raquette monte (position change)
                #la condition >0 (0 not included)permet de ne pas sortir de l'ecran car si on fait 0-paddle_speed =-11 on serait sorti de l'ecran
                #plus y diminue plus on monte 
            if keys[pygame.K_s] and player1_y < SCREEN_HEIGHT - PADDLE_HEIGHT: #SCREEN_HEIGHT - PADDLE_HEIGHT = 600-50=550 soit tout en bas de lecran
                    player1_y += paddle_speed #player1_y = player1_y + paddle_speed
            

            if keys[pygame.K_UP]and player2_y > 0:
                player2_y -= paddle_speed
            if keys[pygame.K_DOWN]and player2_y < SCREEN_HEIGHT - PADDLE_HEIGHT:
                player2_y += paddle_speed
# incrementer (x=5... x+=1 (incremente de 1 et x devient 6))
#decrementer (x=5... x-=1 (decremente de 1 et x devient 4))

        # TODO : IMPLÉMENTATION DU MOUVEMENT DES RAQUETTES POUR L'OPTION "SINGLE PLAYER"
        #
        # 1. Le joueur 1 contrôle sa raquette avec les touches "w" (haut) et "s" (bas), comme dans le mode "multi player".
        if game_mode == 'single player':
            #paddle_speed=11
            if keys[pygame.K_w] and player1_y > 0:
                player1_y -= paddle_speed
            if keys[pygame.K_s] and player1_y < SCREEN_HEIGHT - PADDLE_HEIGHT:
                player1_y += paddle_speed
        # 2. La raquette du joueur 2 (contrôlée par l'ordinateur) doit suivre la position de la balle. Plus précisément : 
        #      - Si la position y de la balle est inférieure au centre de la raquette, la raquette doit monter.
        #      - Si la position y de la balle est supérieure au centre de la raquette, la raquette doit descendre.
            paddlecenter=(PADDLE_HEIGHT//2)+player2_y #pour avoir le centre de la raquette on cherche le centre de la raquette+la hauteur ou ce quelle est
        # 3. Afin de rendre les mouvements de l'adversaire un peu plus vraisemblables, vous devez également ajouter une variable nommée "margin" à la position du centre de la raquette. 
        #    De cette façon, le centre de la raquette de l'adversaire suivra le mouvement de la balle, mais avec un léger décalage. La valeur de la variable "margin" doit varier de façon aléatoire, 
        #    c'est-à-dire : 
        #      - 90% du temps, "margin" doit être égale à 20 = moins lent
        #      - 10% du temps, "margin" doit être égale à 40 = plus lent
        # sans margin la raquette suivrait parfaitement la balle et donc trop fort pour lhumain (plus margin est eleve plus la raquette est lente)
        #mettre les niveau avant que le jeu commence
            if difficulty == 'easy':
                paddle2_speed=paddle_speed-5
            elif difficulty == 'medium':
                paddle2_speed=paddle_speed-4
            else:
                paddle2_speed=paddle_speed #niveau hard
        #margins
            if random.random() < 0.9: #random.random() donne un nombre aleatoire entre 0 et 1
                margin=20
            else:
                margin=40
            if ball_y<paddlecenter-margin and player2_y>0: #si la balle est plus haute que le centre de la raquette
                player2_y-=paddle2_speed #raquette monte car on lui enleve des cm
            if ball_y>paddlecenter+margin and player2_y<SCREEN_HEIGHT-PADDLE_HEIGHT: #si la balle est plus basse que le centre de la raquette
                player2_y+=paddle2_speed #raquette descend car on lui ajoute des cm
# on fait +margin pour permettre un delay(qd c nettement en dessous)
# donc si la balle est en bas de la raquette,la raquette doit descendre pr la suivre
        # 4. Adaptez la vitesse de déplacement de la raquette du joueur 2 selon le niveau de difficulté sélectionné dans le menu "SELECT DIFFICULTY" :
        #     - Pour le niveau "easy", la vitesse de déplacement de la raquette doit être égale à "paddle_speed - 5"
        #     - Pour le niveau "medium", la vitesse de déplacement de la raquette doit être égale à "paddle_speed - 4"
        #     - Pour le niveau "hard", la vitesse de déplacement de la raquette doit être égale à "paddle_speed"
        
        
        


        # TODO : GESTION DU MOUVEMENT DE LA BALLE 
        #
        # 1. Mettre à jour la position de la balle (les variables "ball_x" et "ball_y") en utilisant les variables "ball_velocity_x" et "ball_velocity_y".
        ball_x+=ball_velocity_x
        ball_y+=ball_velocity_y
        # si on aurait pas mit ces lignes, la balle serait restée au centre de l'ecran
        # 2. Gérer les collisions de la balle avec le haut et le bas de la fenêtre de jeu. 
        #    Lorsque la balle atteint le haut ou le bas, sa direction verticale doit être inversée.
        if ball_y<=0 or ball_y>=SCREEN_HEIGHT-BALL_SIZE:
            ball_velocity_y*=-1
        # 3. Gérer les collisions entre la balle et les raquettes. 
        #    Lorsque la balle frappe une raquette, sa direction horizontale doit être inversée.
        if ball_x<=PADDLE_WIDTH+BALL_SIZE and player1_y<=ball_y<=player1_y+PADDLE_HEIGHT:
            ball_velocity_x*=-1
        if ball_x>=SCREEN_WIDTH-PADDLE_WIDTH-BALL_SIZE and player2_y<=ball_y<=player2_y+PADDLE_HEIGHT:
            ball_velocity_x*=-1
            


        # TODO : GESTION DES POINTS ET RÉINITIALISATION DE LA BALLE
        #
        # 1. Vous devez implémenter l'ajout de points lorsqu'un joueur manque la balle et qu'elle frappe l'un des murs.
        if ball_x<0: #si la balle sort a gauche
            player2_score+=1
            ball_x, ball_y, ball_velocity_x, ball_velocity_y = reset_ball(ball_x, ball_y, ball_velocity_x, ball_velocity_y)
        if ball_x>SCREEN_WIDTH: #si la balle sort a droite
            player1_score+=1
            ball_x, ball_y, ball_velocity_x, ball_velocity_y = reset_ball(ball_x, ball_y, ball_velocity_x, ball_velocity_y)


        # 2. Vous devez également réinitialiser la balle pour qu'elle réapparaisse dans le jeu à l'aide de la fonction "reset_ball" que vous avez implémenté



        # Vérifier s'il y a un gagnant
        if player1_score == 11:
            win("PLAYER 1 WINS!")
            return
        if player2_score == 11:
            win("PLAYER 2 WINS!")
            return

        # Affichage des raquettes, de la balle et des points dans la fenêtre du jeu 
        pygame.draw.rect(screen, WHITE, (0, player1_y, PADDLE_WIDTH, PADDLE_HEIGHT))
        pygame.draw.rect(screen, WHITE, (SCREEN_WIDTH - PADDLE_WIDTH, player2_y, PADDLE_WIDTH, PADDLE_HEIGHT))
        pygame.draw.circle(screen, WHITE, (ball_x, ball_y), BALL_SIZE)
        draw_center_line(screen)
        draw_text("PLAYER 1", SCREEN_WIDTH // 4, 18, WHITE, 28, screen)
        draw_text(str(player1_score), SCREEN_WIDTH // 4, 55, WHITE, 36, screen)
        draw_text("PLAYER 2", SCREEN_WIDTH * 3 // 4, 18, WHITE, 28, screen)
        draw_text(str(player2_score), SCREEN_WIDTH * 3 // 4, 55, WHITE, 36, screen)

        # Mise à jour de l'affichage
        pygame.display.flip()

        # Fréquence d'images
        clock.tick(60)

def reset_game():
    """
    Réinitialisation du jeu pour débuter une nouvelle partie
    """
    player1_y = SCREEN_HEIGHT // 2 - PADDLE_HEIGHT // 2
    player2_y = SCREEN_HEIGHT // 2 - PADDLE_HEIGHT // 2
    ball_x = SCREEN_WIDTH // 2
    ball_y = SCREEN_HEIGHT // 2
    ball_velocity_x = BALL_SPEED_X
    ball_velocity_y = BALL_SPEED_Y
    player1_score = 0
    player2_score = 0
    play_game(player1_y, player2_y, player1_score, player2_score, ball_x, ball_y, ball_velocity_x, ball_velocity_y)

def win(winner_message):
    """
    Affichage d'un message lorsqu'il y a un gagnant
    """
    screen.fill(BLACK)

    # Afficher le message du gagnant 
    draw_text(winner_message, SCREEN_WIDTH // 2, SCREEN_HEIGHT // 3, WHITE, 48, screen)
    draw_text("PRESS 'M' TO RETURN TO MAIN MENU", SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2, WHITE, 36, screen)

    # Mise à jour de l'affichage
    pygame.display.flip()

    waiting_for_input = True
    while waiting_for_input:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_m:
                    main_menu()  # Retour au menu principal
                    return
                if event.key == pygame.K_r:
                    reset_game()  # Réinitialisation du jeu
                    return

